#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <stdio.h>
#include <MMsystem.h>

void fullscreen(), tema(), gotoxy(), rule(), about(), SetColorAndBackground(), arrowHere();
int menu(), x=0, y=0, z=0, mx, mn, ex, ye, a=0, pos = 8, pos1 = 8, pos2 = 8;
int ForgC, BackC, realPosition, arrowPosition, dua(), tiga(), empat(), lima() ;
char ser, keyPressed;
int game();

void main(){
	

	system("Color f2");
	fullscreen();
	

	if(PlaySound(TEXT("C:\\Users\\fatur\\Desktop\\bingo gAME\\two.wav"), NULL, SND_ASYNC)){
	
        tema();
}
	menu();
	
}
void SetColorAndBackground(ForgC, BackC) {
    WORD wColor = ((BackC & 0x0F) << 4) + (ForgC & 0x0F);;
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), wColor);
    return;
}

void tema(){
	fullscreen();
	FILE *fp;
	fp=fopen("MAIN.txt", "r");
	do
    {
		ser=getc(fp);
		printf("%c", ser);
	}
	while(ser!=EOF);
	fflush(stdin);
	Sleep(4000);
    system("cls");
}

int menu(){
	
    PlaySound(TEXT("C:\\Users\\fatur\\Desktop\\bingo gAME\\one.wav"), NULL, SND_ASYNC | SND_LOOP);

	int position = 1;
int keyPressed = 0;

#define MAX 4
#define MIN 1

while (keyPressed!=13){
	system("cls");
printf(" ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___\n"); 
printf("(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)\n");
printf("\n");
printf("\t\t          .         .                                                                              .         .          \n");                                                
printf("\t\t         ,8.       ,8.                   .8.           8 8888 b.             8                    ,8.       ,8.          8 8888888888   b.             8 8 8888      88\n"); 
printf("\t\t        ,888.     ,888.                 .888.          8 8888 888o.          8                   ,888.     ,888.         8 8888         888o.          8 8 8888      88\n"); 
printf("\t\t       .`8888.   .`8888.               :88888.         8 8888 Y88888o.       8                  .`8888.   .`8888.        8 8888         Y88888o.       8 8 8888      88\n");
printf("\t\t      ,8.`8888. ,8.`8888.             . `88888.        8 8888 .`Y888888o.    8                 ,8.`8888. ,8.`8888.       8 8888         .`Y888888o.    8 8 8888      88\n"); 
printf("\t\t     ,8'8.`8888,8^8.`8888.           .8. `88888.       8 8888 8o. `Y888888o. 8                ,8'8.`8888,8^8.`8888.      8 888888888888 8o. `Y888888o. 8 8 8888      88\n"); 
printf("\t\t    ,8' `8.`8888' `8.`8888.         .8`8. `88888.      8 8888 8`Y8o. `Y88888o8               ,8' `8.`8888' `8.`8888.     8 8888         8`Y8o. `Y88888o8 8 8888      88\n"); 
printf("\t\t   ,8'   `8.`88'   `8.`8888.       .8' `8. `88888.     8 8888 8   `Y8o. `Y8888              ,8'   `8.`88'   `8.`8888.    8 8888         8   `Y8o. `Y8888 8 8888      88\n"); 
printf("\t\t  ,8'     `8.`'     `8.`8888.     .8'   `8. `88888.    8 8888 8      `Y8o. `Y8             ,8'     `8.`'     `8.`8888.   8 8888         8      `Y8o. `Y8 ` 8888     ,8P\n"); 
printf("\t\t ,8'       `8        `8.`8888.   .888888888. `88888.   8 8888 8         `Y8o.`            ,8'       `8        `8.`8888.  8 8888         8         `Y8o.`   8888   ,d8P\n");  
printf("\t\t,8'         `         `8.`8888. .8'       `8. `88888.  8 8888 8            `Yo           ,8'         `         `8.`8888. 8 888888888888 8            `Yo    `Y88888P'\n");   



	
printf("\n");
printf("  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___ ___   ___  ___  ___  ___  ___  ___  ___\n "); 
printf("(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)\n");


                                                                                
printf("\n\t\t\t\t\t\t\t\t\t\t\t   << Select a Menu >>\n");
	
	printf("\n");
	printf("\n\t\t\t**\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t      **");
	printf("\n\t\t\t**\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t      **");
	printf("\n\t\t\t**\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t      **");
	printf("\n\t\t\t**\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t      **");
	printf("\n");                                                                               
                      
                                                                                                                                                                                                                                              
printf("  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___\n "); 
printf("(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)\n");


    printf("\n\n\n\n\n\n\n\n\n\n\n\n");
printf("[ENT] - Submit    [UP/DOWN] - Select V \t \n");

printf("  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___ \n "); 
printf("(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)\n");

                                                                                
gotoxy(80,21);
arrowHere(1,position); printf(" [1] PLAY GAME");
gotoxy(80,22);
arrowHere(2,position); printf(" [2] RULE");
gotoxy(80,23);
arrowHere(3,position); printf(" [3] ABOUT");
gotoxy(80,24);
arrowHere(4,position); printf(" [4] EXIT");


keyPressed = getch();

if(keyPressed == 80 && position != MAX) {
    position++;
}
else if(keyPressed == 72 && position != MIN) {
    position--;
}
else {
    position = position;
}}                                                                                
if (position==1) {
    system("cls");
	game();
}
if (position==2) {
    rule();
}
if (position==3) {
    about();
}
if (position==4) {
	exit(0);
}}

void rule(){
	system("cls");
	
	printf(" Bingo is a game of probability. In Bingo, players mark off numbers on cards as the numbers are drawn randomly by a caller.\n");
	printf(" The winner is the first person to mark off all his or her numbers. Bingo can be played with 90 balls or 75 balls, depending on where you are.\n");
	
	printf("\n");
	printf("Back [ESC]");
	
	keyPressed = getch ();
	if(keyPressed == 27){
		menu();
	}
}

void about(){
	
	#define ESC 27
	system("cls");
	printf("Game Bingo ini dibuat oleh :\n");
	printf("\n");
	printf("-> Fatur Rahman Stoffel (1806148675)\n");
	printf("-> Josef Eric (1806148725)\n");
	printf("\n");
	printf("\tMahasiswa Teknik Komputer UI 2018\n");
	printf("\n");
	printf("Back [ESC]");
	
	keyPressed = getch();
	if(keyPressed == 27){
		menu();
	}
	
	
	
}   

void fullscreen(){
	keybd_event(VK_MENU, 0x38, 0, 0);
	keybd_event(VK_RETURN, 0x1c, 0, 0);
	keybd_event(VK_RETURN, 0x1c, KEYEVENTF_KEYUP, 0);
	keybd_event(VK_MENU, 0x38, KEYEVENTF_KEYUP, 0);
}                                                                    
void arrowHere(int realPosition, int arrowPosition) {
    if(realPosition == arrowPosition){
    printf("--) - ");
    }
    else {
    printf("      ");
    }
}

void gotoxy(ex, ye)
{
COORD coord;
coord.X = ex;
coord.Y = ye;
SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}


	// Struct Basic
struct node {
   int data;
   struct node *next;
};

// Generate Node pointer
struct node *top1 = NULL;
struct node *current1 = NULL;

struct node *top2 = NULL;
struct node *current2= NULL;

//Create Linked List
void insert1(int data) {
   // Allocate memory for new node;
   struct node *link1 = (struct node*) malloc(sizeof(struct node));

	// Set value 
   link1->data = data;
   link1->next = NULL;

   // If top is empty, create new list
   if(top1==NULL) {
      top1 = link1;
      return;
   }

   current1 = top1;
   
   // move to the end of the list
   while(current1->next!=NULL)
      current1 = current1->next;
   
   // Insert link at the end of the list
   current1->next = link1; 
}

void insert2(int data) {
   // Allocate memory for new node;
   struct node *link2 = (struct node*) malloc(sizeof(struct node));

	// Set value 
   link2->data = data;
   link2->next = NULL;

   // If top is empty, create new list
   if(top2==NULL) {
      top2 = link2;
      return;
   }

   current2 = top2;
   
   // move to the end of the list
   while(current2->next!=NULL)
      current2 = current2->next;
   
   // Insert link at the end of the list
   current2->next = link2; 
}

void display1() {
   struct node *ptr1 = top1;
   int step=0;
 //  printf("\n[top] =>");
   //start from the beginning
   while(ptr1 != NULL) {
      printf("%d	",ptr1->data);
      ptr1 = ptr1->next;
      step+=1;
      if (step%5==0 && step>0)
	  {
	  	printf("\n");
	  }
   }

  // printf(" [null]\n");
}

void display2() {
   struct node *ptr2 = top2;
   int step=0;
 //  printf("\n[top] =>");
   //start from the beginning
   while(ptr2 != NULL) {
      printf("%d	",ptr2->data);
      ptr2 = ptr2->next;
      step+=1;
      if (step%5==0 && step>0)
	  {
	  	printf("\n");
	  }
   }

  // printf(" [null]\n");
}

void play1(int old) {
   int new=0;
   int pos = 0;
   
   if(top1==NULL) {
   	  system("cls");
      printf("\n\nAngka tidak ada\n\n");
      return;
   } 

   current1 = top1;
   while(current1->next!=NULL) {
      if(current1->data == old) {
         current1->data = new;
         //printf("\n%d ada diposisi U%d, diganti dengan %d\n", old, pos+1, new);
         return;
      }
      
      current1 = current1->next;
      pos++;
   }
   
   printf("%d tidak ada\n", old);
}

void play2(int old) {
   int new=0;
   int pos = 0;
   
   if(top2==NULL) {
   	  system("cls");
      printf("\n\nAngka tidak ada\n\n");
      return;
   } 

   current2 = top2;
   while(current2->next!=NULL) {
      if(current2->data == old) {
         current2->data = new;
         //printf("\n%d ada diposisi U%d, diganti dengan %d\n", old, pos+1, new);
         return;
      }
      
      current2 = current2->next;
      pos++;
   }
   
   printf("%d tidak ada\n", old);
}

int cekBingo(int a, int b)
{
	system("cls");
	if (a==1)
	{
		printf("	B	");
	}
	else if (a==2)
	{
		printf("	B	");		
		printf("	I	");
	}
	else if (a==3)
	{
		printf("	B	");		
		printf("	I	");
		printf("	N	");		
	}
	else if (a==4)
	{
		printf("	B	");		
		printf("	I	");
		printf("	N	");		
		printf("	G	");
	}
	else if (a==5)
	{
		printf("	B	");		
		printf("	I	");
		printf("	N	");		
		printf("	G	");
		printf("	O	");
	}
	
	if (b==1)
	{
		printf("	B	");
	}
	else if (b==2)
	{
		printf("	B	");		
		printf("	I	");
	}
	else if (b==3)
	{
		printf("	B	");		
		printf("	I	");
		printf("	N	");		
	}
	else if (b==4)
	{
		printf("	B	");		
		printf("	I	");
		printf("	N	");		
		printf("	G	");
	}
	else if (b==5)
	{
		printf("	B	");		
		printf("	I	");
		printf("	N	");		
		printf("	G	");
		printf("	O	");
	}
	
	if (a==5 || b<5)
	{
		return 1;
	}
	else if (b==5 || a<5)
	{
		return 2;
	}
	else
	{
		return 0;
	}					
}

int cekMenang(int *arr,int *arr2){
	int bingo1=0,bingo2=0;
//CEK PLAYER 1
//----BARIS-------
	if(arr[0]==0 && arr[1]==0 && arr[2]==0 && arr[3]==0 && arr[4]==0)
	{
		bingo1+=1;
	}
	return cekBingo(bingo1,bingo2);	
	if(arr[5]==0 && arr[6]==0 && arr[7]==0 && arr[8]==0 && arr[9]==0)
	{
		bingo1+=1;
	}
	return cekBingo(bingo1,bingo2);	
	if(arr[10]==0 && arr[11]==0 && arr[12]==0 && arr[13]==0 && arr[14]==0)
	{
		bingo1+=1;
	}
	return cekBingo(bingo1,bingo2);	
	if(arr[15]==0 && arr[16]==0 && arr[17]==0 && arr[18]==0 && arr[19]==0)
	{
		bingo1+=1;
	}
	return cekBingo(bingo1,bingo2);	
	if(arr[20]==0 && arr[21]==0 && arr[22]==0 && arr[23]==0 && arr[24]==0)
	{
		bingo1+=1;
	}
	return cekBingo(bingo1,bingo2);	
//----KOLOM-----
	if(arr[0]==0 && arr[5]==0 && arr[10]==0 && arr[15]==0 && arr[20]==0)
	{
		bingo1+=1;
	}
	return cekBingo(bingo1,bingo2);
	if(arr[1]==0 && arr[6]==0 && arr[11]==0 && arr[16]==0 && arr[21]==0)
	{
		bingo1+=1;
	}
	return cekBingo(bingo1,bingo2);	
	if(arr[2]==0 && arr[7]==0 && arr[12]==0 && arr[17]==0 && arr[22]==0)
	{
		bingo1+=1;
	}
	return cekBingo(bingo1,bingo2);	
	if(arr[3]==0 && arr[8]==0 && arr[13]==0 && arr[18]==0 && arr[23]==0)
	{
		bingo1+=1;
	}
	return cekBingo(bingo1,bingo2);	
	if(arr[4]==0 && arr[9]==0 && arr[14]==0 && arr[19]==0 && arr[24]==0)
	{
		bingo1+=1;
	}							
	return cekBingo(bingo1,bingo2);	
// -- DIAOGNAL ---
	if(arr[0]==0 && arr[6]==0 && arr[12]==0 && arr[18]==0 && arr[24]==0)
	{
		bingo1+=1;
	}
	return cekBingo(bingo1,bingo2);	
	if(arr[4]==0 && arr[8]==0 && arr[12]==0 && arr[16]==0 && arr[20]==0)
	{
		bingo1+=1;
	}	
	return cekBingo(bingo1,bingo2);
//CEK PLAYER 2
//----BARIS-------
	if(arr2[0]==0 && arr2[1]==0 && arr2[2]==0 && arr2[3]==0 && arr2[4]==0)
	{
		bingo2+=1;
	}
	cekBingo(bingo1,bingo2);	
	if(arr2[5]==0 && arr2[6]==0 && arr2[7]==0 && arr2[8]==0 && arr2[9]==0)
	{
		bingo2+=1;
	}
	cekBingo(bingo1,bingo2);	
	if(arr2[10]==0 && arr2[11]==0 && arr2[12]==0 && arr2[13]==0 && arr2[14]==0)
	{
		bingo2+=1;
	}
	cekBingo(bingo1,bingo2);	
	if(arr2[15]==0 && arr2[16]==0 && arr2[17]==0 && arr2[18]==0 && arr2[19]==0)
	{
		bingo2+=1;
	}
	cekBingo(bingo1,bingo2);	
	if(arr2[20]==0 && arr2[21]==0 && arr2[22]==0 && arr2[23]==0 && arr2[24]==0)
	{
		bingo2+=1;
	}
	cekBingo(bingo1,bingo2);	
//----KOLOM-----
	if(arr2[0]==0 && arr2[5]==0 && arr2[10]==0 && arr2[15]==0 && arr2[20]==0)
	{
		bingo2+=1;
	}
	cekBingo(bingo1,bingo2);	
	if(arr2[1]==0 && arr2[6]==0 && arr2[11]==0 && arr2[16]==0 && arr2[21]==0)
	{
		bingo2+=1;
	}
	cekBingo(bingo1,bingo2);	
	if(arr2[2]==0 && arr2[7]==0 && arr2[12]==0 && arr2[17]==0 && arr2[22]==0)
	{
		bingo2+=1;
	}
	cekBingo(bingo1,bingo2);	
	if(arr2[3]==0 && arr2[8]==0 && arr2[13]==0 && arr2[18]==0 && arr2[23]==0)
	{
		bingo2+=1;
	cekBingo(bingo1,bingo2);		
	}
	if(arr2[4]==0 && arr2[9]==0 && arr2[14]==0 && arr2[19]==0 && arr2[24]==0)
	{
		bingo2+=1;
	}							
	cekBingo(bingo1,bingo2);	
// -- DIAOGNAL ---
	if(arr2[0]==0 && arr2[6]==0 && arr2[12]==0 && arr2[18]==0 && arr2[24]==0)
	{
		bingo2+=1;
	}
	cekBingo(bingo1,bingo2);	
	if(arr2[4]==0 && arr2[8]==0 && arr2[12]==0 && arr2[16]==0 && arr2[20]==0)
	{
		bingo2+=1;
	}
	cekBingo(bingo1,bingo2);		
}



int game() {
  int arr[25],arr2[25], i, j, k,l, size=25,size2=25,in,step=0,size1;
  int MenangSuit=0,menang=0,input;
   
//------------ PLAYER 1 ------------------   
   for (i = 0; i < size; i++)
   {
   for(l=0; l<25; l++)
   {
   		if(l>0 && l%5==0)
		{
			printf("\n");   
		}
		if(arr[l]%26!=0 && arr[l]>0)
		{
	//	printf("U%d	",l+1);
   		printf("%d	",arr[l]);
	   	}
   		else
		   {
		   	printf("U%d	",l+1);
		   }
   }
	printf("\n\nInput U%d = ",i+1);scanf("%d", &in);
	while(in<=0 || in>25)
	  {
	  	system("cls");
   		for(l=0; l<25; l++)
   		{
   		if(l>0 && l%5==0)
		{
			printf("\n");   
		}
		if(arr[l]%26!=0 && arr[l]>0)
		{
	//	printf("U%d	",l+1);
   		printf("%d	",arr[l]);
	   	}
   		else
		   {
		   	printf("U%d	",l+1);
		   }
   		}	  	
		printf("\n\nInput hanya 1 sampai 25\n\nInput U%d = ",i+1);scanf("%d", &in);
					  	
//		printf("\n\nInput hanya 1 sampai 25\n\n");	 
	  }
		arr[i]=in;
		system("cls");
	//	step+=1;
	}
//		printf("Step =	%d",step);	
   //printf("\nList of Unique Numbers:");
   for (i = 0; i < size; i++) {
      for (j = i + 1; j < size;) {
         if (arr[j] == arr[i]) {
            for (k = j; k < size; k++) {
               arr[k] = arr[k + 1];
            }
            size--;
         } else
            j++;
      }
   }
   size1= size;
  // printf("\n\nSize = %d\n\n",size1);
 /*  for (i = 0; i < size; i++) {
      printf("%d ", arr[i]);
   }
   */
   if (size1<25)
   {
   for (size1; size1 < 25; size1++)
    {
	system("cls");
   		for(l=0; l<25; l++)
   		{
   		if(l>0 && l%5==0)
		{
			printf("\n");   
		}
		if(arr[l]%26!=0 && arr[l]>0)
		{
	//	printf("U%d	",l+1);
   		printf("%d	",arr[l]);
	   	}
   		else
		   {
		   	printf("U%d	",l+1);
		   }
   		}		    	
	printf("\n\nInput U%d = ",size1+1);scanf("%d", &in);
	while(in<0 || in>25 )
	  {
	  	system("cls");
   		for(l=0; l<25; l++)
   		{
   		if(l>0 && l%5==0)
		{
			printf("\n");   
		}
		if(arr[l]%26!=0 && arr[l]>0)
		{
	//	printf("U%d	",l+1);
   		printf("%d	",arr[l]);
	   	}
   		else
		   {
		   	printf("U%d	",l+1);
		   }
   		}		
		printf("\n\nInput hanya 1 sampai 25\n\nInput U%d = ",size1+1); scanf("%d", &in);
//		printf("\n\nInput hanya 1 sampai 25\n\n");
	//printf("Input U%d = ",size1+1); scanf("%d", &in);			  	
	  }
		arr[size1]=in;
		system("cls");
//		step+=1;
	}   	
   }
   else
   {
   for(l=0; l<25; l++)
   {
   		if(l>0 && l%5==0)
		{
			printf("\n");   
		}
		if(arr[l]%26!=0 && arr[l]>0)
		{
	//	printf("U%d	",l+1);
   		printf("%d	",arr[l]);
	   	}
   		else
		   {
		   	printf("U%d	",l+1);
		   }
   }
   }
   for (i=0; i<25; i++)
   {
   		insert1(arr[i]);
   }	
	printf("\n\n----------------------");
	system("cls");
//---------PLAYER 2------------------
   
   size=25;
   for (i = 0; i < size; i++)
   {
   for(l=0; l<25; l++)
   {
   		if(l>0 && l%5==0)
		{
			printf("\n");   
		}
		if((arr2[l]%26!=0 && arr2[l]>0))
		{
	//	printf("U%d	",l+1);
   		printf("%d	",arr2[l]);
	   	}
   		else
		   {
		   	printf("U%d	",l+1);
		   }
   }
	printf("\n\nInput U%d = ",i+1);scanf("%d", &in);
	while(in<0 || in>25)
	  {
	  	system("cls");
   		for(l=0; l<25; l++)
   		{
   		if(l>0 && l%5==0)
		{
			printf("\n");   
		}
		if(arr2[l]%26!=0 && arr2[l]>0)
		{
	//	printf("U%d	",l+1);
   		printf("%d	",arr2[l]);
	   	}
   		else
		   {
		   	printf("U%d	",l+1);
		   }
   		}
		printf("\n\nInput hanya 1 sampai 25\n\nInput U%d = ",i+1);scanf("%d", &in);			  	
//		printf("\n\nInput hanya 1 sampai 25\n\n");	  
	  }
		arr2[i]=in;
		system("cls");
	//	step+=1;
	}
//		printf("Step =	%d",step);	
   //printf("\nList of Unique Numbers:");
   for (i = 0; i < size; i++) {
      for (j = i + 1; j < size;) {
         if (arr[j] == arr[i]) {
            for (k = j; k < size; k++) {
               arr[k] = arr[k + 1];
            }
            size--;
         } else
            j++;
      }
   }
   size2= size;
  // printf("\n\nSize = %d\n\n",size1);
 /*  for (i = 0; i < size; i++) {
      printf("%d ", arr[i]);
   }
   */
   if (size2<25)
   {
   for (size2; size2 < 25; size2++)
    {
   for (i = 0; i < size; i++)
   {
   for(l=0; l<25; l++)
   {
   		if(l>0 && l%5==0)
		{
			printf("\n");   
		}
		if(arr2[l]%26!=0 && arr2[l]>0)
		{
	//	printf("U%d	",l+1);
   		printf("%d	",arr2[l]);
	   	}
   		else
		   {
		   	printf("U%d	",l+1);
		   }
   }
	printf("\n\nInput U%d = ",i+1);scanf("%d", &in);
	while(in<0 || in>25)
	  {
	  	system("cls");
   		for(l=0; l<25; l++)
   		{
   		if(l>0 && l%5==0)
		{
			printf("\n");   
		}
		if(arr2[l]%26!=0 && arr2[l]>0)
		{
	//	printf("U%d	",l+1);
   		printf("%d	",arr2[l]);
	   	}
   		else
		   {
		   	printf("U%d	",l+1);
		   }
   		}
		printf("\n\nInput hanya 1 sampai 25\n\nInput U%d = ",i+1);scanf("%d", &in);		  	
	//	printf("\n\nInput hanya 1 sampai 25\n\n");	
	  }
		arr[size2]=in;
		system("cls");
//		step+=1;
	}   	
   }
	}
   else
   {
   for(l=0; l<25; l++)
   {
   		if(l>0 && l%5==0)
		{
			printf("\n");   
		}
		if(arr2[l]%26!=0 && arr2[l]>0)
		{
	//	printf("U%d	",l+1);
   		printf("%d	",arr2[l]);
	   	}
   		else
		   {
		   	printf("U%d	",l+1);
		   }
   }
   }
   for (i=0; i<25; i++)
   {
   		insert2(arr2[i]);
   }	   
   
   printf("\n\n\n\n");
   system("cls");
   display2();   
   printf("\n\n----------------------");
   system("cls");   

   display1();
   printf("\n\n\n\n");
   display2();
   sleep(2);
   system("cls");
   MenangSuit=1;

   if (MenangSuit==1)
   {
   		while(menang==0)
		   {
		   		display1();
		   		printf("\n\nPlayer 1\n\nMasukan Angka yang akan dilingkari (diberi nilai 0)	  =	"); scanf("%d",&input);
		   		sleep(2);
				system("cls");
		   		play1(input); play2(input);   		   		
		   		menang = cekMenang(arr,arr2);
		   		sleep(2);
				system("cls");
				display2();
		   		printf("\n\nPlayer 2\n\nMasukan Angka yang akan dilingkari (diberi nilai 0)	  =	"); scanf("%d",&input);
		   		sleep(2);
				system("cls");
		   		play1(input); play2(input); 		   		
				menang = cekMenang(arr,arr2);
		   }
   }
   
   else if (MenangSuit==2)
   {
   		while(menang==0)
		   {
		   		display2();
		   		printf("\n\nPlayer 2\n\nMasukan Angka yang akan dilingkari (diberi nilai 0)	  =	"); scanf("%d",&input);
		   		sleep(2);
				system("cls");
		   		play1(input); play2(input); 
				display1();
				menang = cekMenang(arr,arr2);
		   		printf("\n\nPlayer 1\n\nMasukan Angka yang akan dilingkari (diberi nilai 0)	  =	"); scanf("%d",&input);
		   		sleep(2);
				system("cls");
		   		play1(input); play2(input); 		   		
				menang = cekMenang(arr,arr2);
		   }   	
   }

 
   return 0;
}




	/*	int position = 1;
        int keyPressed = 0;
     
#define ESC 27
#define MAX 4
#define MIN 1
	while (keyPressed!=13){
	system("cls");
printf(" ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___\n"); 
printf("(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)\n");
printf("\n");                                                                                                                          
                                                                                                                           
printf("\t\t\t\t        CCCCCCCCCCCCCHHHHHHHHH     HHHHHHHHH     OOOOOOOOO          OOOOOOOOO        SSSSSSSSSSSSSSS EEEEEEEEEEEEEEEEEEEEEE\n");
printf("\t\t\t\t     CCC::::::::::::CH:::::::H     H:::::::H   OO:::::::::OO      OO:::::::::OO    SS:::::::::::::::SE::::::::::::::::::::E\n");
printf("\t\t\t\t   CC:::::::::::::::CH:::::::H     H:::::::H OO:::::::::::::OO  OO:::::::::::::OO S:::::SSSSSS::::::SE::::::::::::::::::::E\n");
printf("\t\t\t\t  C:::::CCCCCCCC::::CHH::::::H     H::::::HHO:::::::OOO:::::::OO:::::::OOO:::::::OS:::::S     SSSSSSSEE::::::EEEEEEEEE::::E\n");
printf("\t\t\t\t C:::::C       CCCCCC  H:::::H     H:::::H  O::::::O   O::::::OO::::::O   O::::::OS:::::S              E:::::E       EEEEEE\n");
printf("\t\t\t\tC:::::C                H:::::H     H:::::H  O:::::O     O:::::OO:::::O     O:::::OS:::::S              E:::::E\n");             
printf("\t\t\t\tC:::::C                H::::::HHHHH::::::H  O:::::O     O:::::OO:::::O     O:::::O S::::SSSS           E::::::EEEEEEEEEE\n");   
printf("\t\t\t\tC:::::C                H:::::::::::::::::H  O:::::O     O:::::OO:::::O     O:::::O  SS::::::SSSSS      E:::::::::::::::E\n");   
printf("\t\t\t\tC:::::C                H:::::::::::::::::H  O:::::O     O:::::OO:::::O     O:::::O    SSS::::::::SS    E:::::::::::::::E\n");   
printf("\t\t\t\tC:::::C                H:::::H     H:::::H  O:::::O     O:::::OO:::::O     O:::::O            S:::::S  E:::::E\n");             
printf("\t\t\t\t C:::::C       CCCCCC  H:::::H     H:::::H  O::::::O   O::::::OO::::::O   O::::::O            S:::::S  E:::::E       EEEEEE\n");
printf("\t\t\t\t  C:::::CCCCCCCC::::CHH::::::H     H::::::HHO:::::::OOO:::::::OO:::::::OOO:::::::OSSSSSSS     S:::::SEE::::::EEEEEEEE:::::E\n");
printf("\t\t\t\t   CC:::::::::::::::CH:::::::H     H:::::::H OO:::::::::::::OO  OO:::::::::::::OO S::::::SSSSSS:::::SE::::::::::::::::::::E\n");
printf("\t\t\t\t     CCC::::::::::::CH:::::::H     H:::::::H   OO:::::::::OO      OO:::::::::OO   S:::::::::::::::SS E::::::::::::::::::::E\n");
printf("\t\t\t\t        CCCCCCCCCCCCCHHHHHHHHH     HHHHHHHHH     OOOOOOOOO          OOOOOOOOO      SSSSSSSSSSSSSSS   EEEEEEEEEEEEEEEEEEEEEE\n");
                                                                                                                           
printf("\n");                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
printf("  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___\n "); 
printf("(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)\n");


                                                                                
printf("\n\t\t\t\t\t\t\t\t\t\t\t   << Select a Menu >>\n");
	
	printf("\n");
	printf("\n\t\t\t**\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t      **");
	printf("\n\t\t\t**\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t      **");
	printf("\n\t\t\t**\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t      **");
	printf("\n\t\t\t**\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t      **");
	printf("\n");                                                                               
                      
                                                                                                                                                                                                                                              
printf("  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___\n "); 
printf("(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)\n");


    printf("\n\n\n\n\n\n\n\n\n\n\n\n");
printf("[ENT] - Submit    [UP/DOWN] - Select V  [ESC] - Back\t \n");

printf("  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___\n "); 
printf("(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)\n");

                                                                                
gotoxy(80,25);
arrowHere(1,position); printf(" [1] BERDUA");
gotoxy(80,26);
arrowHere(2,position); printf(" [2] BERTIGA");
gotoxy(80,27);
arrowHere(3,position); printf(" [3] BEREMPAT");
gotoxy(80,28);
arrowHere(4,position); printf(" [4] BERLIMA");



keyPressed = getch();
if(keyPressed == 27){
	menu();
}
if(keyPressed == 80 && position != MAX) {
    position++;
}
else if(keyPressed == 72 && position != MIN) {
    position--;
}
else {
    position = position;
}}                                                                                
if (position==1) {
    dua();
}
if (position==2) {
    tiga();
}
if (position==3) {
    empat();
}
if (position==4) {
	lima();
}
}

int dua(){
	
}	

int tiga(){
	
}

int empat(){
	
}

int lima(){
	
}
*/
